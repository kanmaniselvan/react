import React, {Component} from 'react';
import ReactDOM from 'react-dom';

class Page extends Component{
  render(){
    return(
      <h1>Hello World</h1>
    );
  }
}

ReactDOM.render(<Page />, document.getElementById('plug'));
